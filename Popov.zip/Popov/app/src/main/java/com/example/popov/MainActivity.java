package com.example.popov;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etEmail, etPassword;
    private Button btnLogin, btnParameter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Инициализация элементов формы авторизации
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnParameter = findViewById(R.id.btnParameter);

        // Обработчик кнопки "Войти"
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = etEmail.getText().toString().trim();
                String password = etPassword.getText().toString().trim();

                // Проверяем логин и пароль
                if (email.equals("admin@admin.ru") && password.equals("123")) {
                    // Успешная авторизация
                    Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                    intent.putExtra("message", "Добро пожаловать, admin!");
                    startActivity(intent);
                } else {
                    // Ошибка авторизации
                    Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                    intent.putExtra("message", "Ошибка авторизации!");
                    startActivity(intent);
                }
            }
        });

        // Обработчик кнопки для передачи параметра
        btnParameter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Переход на ParameterActivity с передачей фамилии
                Intent intent = new Intent(MainActivity.this, ParameterActivity.class);
                intent.putExtra("surname", "Попов");
                startActivity(intent);
            }
        });
    }
}