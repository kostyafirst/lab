package com.example.popov;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ParameterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parameter);

        TextView tvParam = findViewById(R.id.tvParam);
        Button btnBack = findViewById(R.id.btnBack);

        // Получаем переданную фамилию
        Intent intent = getIntent();
        if (intent.hasExtra("surname")) {
            String surname = intent.getStringExtra("surname");
            tvParam.setText("Переданная фамилия: " + surname);
        }

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Возвращаемся на MainActivity
            }
        });
    }
}