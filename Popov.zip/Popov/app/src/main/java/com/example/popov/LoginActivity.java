package com.example.popov;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText etEmail, etPassword;
    private Button btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Инициализация элементов
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = etEmail.getText().toString().trim();
                String password = etPassword.getText().toString().trim();

                // Проверяем логин и пароль
                if (email.equals("admin@admin.ru") && password.equals("123")) {
                    // Успешная авторизация
                    Intent intent = new Intent(LoginActivity.this, SecondActivity.class);
                    intent.putExtra("message", getString(R.string.welcome_message));
                    startActivity(intent);
                } else {
                    // Ошибка авторизации
                    Intent intent = new Intent(LoginActivity.this, SecondActivity.class);
                    intent.putExtra("message", getString(R.string.auth_error));
                    startActivity(intent);
                }
            }
        });
    }
}